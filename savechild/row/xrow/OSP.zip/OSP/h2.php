<html>
<head>
<link rel="stylesheet" type="text/css" href="Style\h.css"></head>
<body>
	<center> <div><h1>Mycart.com</h1></div>	 </center>
<div style="margin-top:-12px;margin-left:350px">
		
			<ul id="nav">
					<li style="float: left; width: 150px; text-align: center;"><a href="home.php"><b>Home</b></a></li>
                    <li style="float: left; width: 150px; text-align: center;"><a href="ulog.php"><b>Login</b></a></li>  
					<li style="float: left; width: 150px; text-align: center;"><a href="reg.php"><b>Registration</b></a></li> 

			</ul>

			
	 </div>

</body>
</html>