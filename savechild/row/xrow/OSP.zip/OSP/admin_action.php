<?php
 $pname=$_POST['pname'];
 $ptype=$_POST['ptype'];
 $pbrand=$_POST['pbrand'];
 $pdes=$_POST['pdes'];
 $pcost=$_POST['pcost'];
 $ifile=$_FILES['ifile']['name'];
 if(@file_exists("osp/".$FILES['ifile']['name']))
{
	echo "Exist";
}
else
{ 
    if($_FILES['ifile']['type']=='image/jpeg')
	{
		move_uploaded_file($_FILES['ifile']['tmp_name'],"i/".$_FILES['ifile']['name']);
	}
}
$con=mysql_connect("localhost","root","");
mysql_select_db('osp');
$sql="insert into product Values('','$pname','$ptype','$pbrand','$pdes','$pcost','$ifile')";
$result=mysql_query($sql,$con);
header('location:adminpanel.php');
mysql_close($con);
 
?>