<?php
include "h1.php";
  @session_start();

if(isset($_SESSION['name']))
{
 $con=mysql_connect('localhost','root','');
	mysql_select_db('osp');
	$uname=$_SESSION['name'];
if(isset($_REQUEST['pid']))
{
  $pid=$_REQUEST['pid'];

  
 
  $isql="insert into mycart Values('$pid','$uname')";
  $res=mysql_query($isql,$con);
  }
	$ssql="select pid,pname,pcost,ifile from product where pid in (select pid from mycart where uname='$uname')";
	$result=mysql_query($ssql,$con);
	$tcost=0;
	while($row=mysql_fetch_array($result))
	{ 
	  echo "<div style='float:left;margin-right:10px;'>";
	  $tcost=$tcost+$row['pcost'];
	  echo "<div style='float:left;margin-right:10px;'>";
	  echo "<img style='width:400px;height=1200px' src=i/".$row['ifile'].">";
	  echo "</div>";
	  echo "<div>";
	  echo "Product Name :".$row['pname']."<br>";
	  echo "Product Cost :".$row['pcost']."<br>";
	  echo "<a href='remove.php?pid=".$row['pid']."'>Remove From MyCart <<</a>";
	  echo "</div>";
	  echo "</div>";
    }  
	echo "<br><br><br><div><a href='home.php'>Proceed</a></div>";
    echo "<div>Total cost :".$tcost."</div>";
	echo "<div><a href='pay.php'>PAY NOW</a></div>";
	
}
else
{
 echo "Log in";
}
?>