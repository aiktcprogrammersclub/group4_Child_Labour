<?php
$ptid=$_REQUEST['ptid'];
$con=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db("osp",$con) or die(mysql_error()) ;
$sql="select * from pbrand where ptid in(select ptid from pbrand where ptid='$ptid')";
$res=mysql_query($sql,$con) or die(mysql_error());
if(mysql_num_rows($res)>0)
{	
	echo '<select id="pbrand" name="pbrand">';
			while($row=mysql_fetch_assoc($res))
			{
				echo'<option value="'.$row['bid'].'">'.$row['bname'].'</option>'; 				
			}
	echo '</select>';
}
		else
		{
			echo "<option>Wrong Choice</option>";
		}

?>