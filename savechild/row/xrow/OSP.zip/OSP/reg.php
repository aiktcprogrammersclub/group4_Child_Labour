<html>
<head><title>OSP-Registration</title>
<link rel="stylesheet" type="text/css" href="Style\h.css"></head>

<body>
<div id='wrap'>
<?php include 'h2.php';?><br><br><br>
<div style='margin-left:450px'>
<form action='reg1.php' method='post'>
<table>
<tr>
<td>NAME:</td>
<td><input type='text' name='name' id='name'></td>
</tr>
<tr>
<td>E-MAIL ID:</td>
<td><input type='email' name='email' id='email'></td>
</tr>
<tr><td>ADDRESS:</td>
<td><textarea name="add" id="add"></textarea></td>
</tr>
<tr><td>CONTACT NO:</td>
<td><input type='text' name='no' id='no'></td>
</tr>
<tr>
<td>PASSWORD :</td><td><input type='password' name='pwd' id='pwd'></td>
</tr>
<tr>
<td>CONFIRM PASSWORD :</td><td><input type='password' name='cpwd' id='cpwd'></td>
</tr>
<tr>
<td colspan=2><br><center>
	 <input type='Submit' value='Submit'>&nbsp;&nbsp;<input type='reset' value='Reset'>
	 </center></td>
</tr>
</table>
</form>
</div>
</div>
</body>
</html>