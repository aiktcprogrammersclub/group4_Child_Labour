
<?php
include 'h2.php';
session_start();
unset($_SESSION['name']);
session_destroy();
echo "<br><br><br>";
echo "thank you for visiting";
echo "<br>relogin";
echo "<a href='ulog.php'>LOGIN</a>";
?>