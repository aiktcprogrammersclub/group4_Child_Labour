<html>
<head>
<link rel="stylesheet" type="text/css" href="Style\h.css"></head>
<body>
	<center> <div><h1>Mycart.com</h1></div>	 </center>
	<div>
	<?php 
	    @session_start();
		if(isset($_SESSION['name']))
		{
		echo "<div style='float:right'>"; 
		echo 'welcome '.$_SESSION['name'];
		echo "</div>";}
	?>
	</div>
<div style="margin-top:-12px;margin-left:250px">
		
			<ul id="nav">
					<li style="float: left; width: 150px; text-align: center;"><a href="home.php"><b>Home</b></a></li>
                    <li style="float: left; width: 150px; text-align: center;"><a href="mycart.php"><b>My Cart</b></a></li>  
					<li style="float: left; width: 150px; text-align: center;"><a href="ulogout.php"><b>Logout</b></a></li> 

			</ul>

			
	 </div>

</body>
</html>