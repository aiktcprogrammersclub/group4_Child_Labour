<?php
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];
if($uname=='shrima'&&$pwd=='sai')
{
	header('location:adminpanel.php');
}
else
{
echo "Not a valid user";
}
?>