<html>
<head>
<title>OSP_adminpanel</title>
	<script type="text/javascript">
		function show_brand(value)
		{
			var xmlhttp;
			if(window.XMLHttpRequest)
		   {
			xmlhttp=new XMLHttpRequest();
		   }
		   else
		   {
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		   }
		   
		   	xmlhttp.onreadystatechange=function()
			{	
				if(xmlhttp.readyState==4)
				{	
					document.getElementById('brand').innerHTML=xmlhttp.responseText;
				}
			}
		xmlhttp.open("GET","get_brand.php?ptid="+value,true);
		xmlhttp.send();
		}
	</script>
	
</head>
<body>
	<form action='admin_action.php' method='post' enctype='multipart/form-data' >
<table>
	<tr><td>Product Name:</td><td><input type='text' name='pname' id='pname'></td></tr>
	<tr><td>Product Type:</td>
	<td>
		<?php
			$con=mysql_connect('localhost','root','') or die(mysql_error());
			mysql_select_db("osp",$con) or die(mysql_error());
			$sql="select * from ptype";
			$res=mysql_query($sql,$con) or die(mysql_error());
			if(mysql_num_rows($res)>0)
			{
				echo '<select id="ptype" name="ptype" onchange="show_brand(this.value)">';
				while($row=mysql_fetch_assoc($res))
				{
					echo'<option value="'.$row['ptid'].'">'.$row['ptname'].'</option>';
				}
				echo '</select>';
			}
		?>
	</td>
	</tr>
	<tr><td>Brand:</td>
	<td><div id='brand'></div>
	</td>
	</tr>	
	<tr>
		<td>Product Description :</td>
		<td>
			<input type='text' name='pdes' id='pdes' style='width:150px;height:30px'>
		</td>
	<tr>
	<tr><td>Cost:</td><td><input type='text' name='pcost' id='pcost'></td></tr>
	 <tr>
     <td>Image</td>
	 <td><input type='file' name='ifile' id='ifile'></td>
	 </tr>
	 <tr><td colspan=2><br><center>
	 <input type='Submit' value='Submit'>&nbsp;&nbsp;<input type='reset' value='Reset'>
	 </center></td></tr>
</table>
	</form>
</body>
</html>