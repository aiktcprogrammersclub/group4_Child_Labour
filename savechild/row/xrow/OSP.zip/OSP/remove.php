<?php
 $pid=$_REQUEST['pid'];
 @session_start();
 $uname=$_SESSION['name'];
 $con=mysql_connect('localhost','root','');
 mysql_select_db('osp');
 $dsql="Delete from mycart where pid='$pid' AND uname='$uname'";
 $res=mysql_query($dsql,$con);
 header('location:mycart.php');
?>