<?php
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];
$con=mysql_connect("localhost","root","");
mysql_select_db('osp');
$sql="select email,pwd from reg where email='$uname' and pwd='$pwd'";
$res=mysql_query($sql,$con);
if(mysql_num_rows($res)>0) 
{
	session_start();
	$_SESSION['name']=$uname;
	include "h1.php";
	include "home.php";
}
else
{
 include "h2.php";
 echo '<br><br><br>Try again ';
}
mysql_close($con);
?>