<html>
<head>
<title>osp_home</title>
<link rel="stylesheet" type="text/css" href="Style\h.css"></head>
</head>
<body>	<br><br><br>
   <div id='wrap'> 
   <?php 
		$con=mysql_connect('localhost','root','');
		mysql_select_db('osp',$con);
		$sql='select ifile,pname,pid from product';
		$idis=mysql_query($sql,$con);
		echo '<br>';
		while($row=mysql_fetch_array($idis))
		{ 

		 echo "<div style='float:left;margin-right:30;border:1px solid;padding:5px'>";
		 echo "<img style='width:200px;height:300px;' src='i/".$row[0]."'>";
		  echo "<br><br><center><a href='pdes.php?pid=".$row[2]."'>".$row[1]."</a></center><br>";
		 echo "</div>";
		 
		}
		
	?>
	</div>
</body>
</html>