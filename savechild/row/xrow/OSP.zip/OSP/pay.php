<html>
<head>
<title>payment</title>
</head>
<body>
<form>
CARD TYPE:<select name="ctype" id="ctype">
<option value='master'>master</option>
<option value='visa'>visa</option>
</select><br>
CARD NO  :<input type="number" name="crd">
</form>
</body>
</html>