<html>
<head>
<title>Admin Login</title>
</head>

<body>
	<form action='adminlogin1.php' method='post'>
		<table>
			<tr><td>User Id</td><td><input type='text' name='uname' id='uname'></td></tr>
			<tr><td>Password</td><td><input type='password' name='pwd' id='pwd'></td></tr>
			<tr><td colspan=2><center><input type='Submit' value='Submit'></center></td></tr>			
		</table>
	</form>
	<div id='d1'></div>
</body>
</html>