<?php 
$name=$_POST['name'];
$email=$_POST['email'];
$add=$_POST['add'];
$no=$_POST['no'];
$pwd=$_POST['pwd'];
$con=mysql_connect("localhost","root","");
mysql_select_db('osp');
$sql="insert into reg Values('','$name','$email','$add','$no','$pwd')";
$result=mysql_query($sql,$con);
if($result!=null)
{
echo "registration successful!!";
}
else
{
echo "please try again";
header("location:reg.php");
}
mysql_close($con);
?>