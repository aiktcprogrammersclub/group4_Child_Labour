<?php 
$pid=$_REQUEST['pid'];
$con=mysql_connect('localhost','root','');
mysql_select_db('osp');
$sql="select * from product where pid='$pid'";
$result=mysql_query($sql,$con);
$pid;
while($row=mysql_fetch_array($result))
{ 
  $pid=$row[0];
  echo "<div style='float:left;margin-right:10px;'>";
  echo "<img style='width:400px;height=1200px' src=i/".$row[6].">";
  echo "</div>";
  echo "<div>";
  echo "Product Name :".$row[1]."<br>";
  echo "Product Type:".$row[2]."<br>";
  echo "Product Brand :".$row[3]."<br>";
  echo "Product Description :".$row[4]."<br>";
  echo "Product Cost :".$row[5]."<br>";
  echo "</div>";
}
echo "<a href='mycart.php?pid=".$pid."'>Add to MyCart >></a>";
mysql_close();
?> 